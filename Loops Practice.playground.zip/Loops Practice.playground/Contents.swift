let cities = ["Austin", "Denver", "Chicago", "Seattle", "Miami"]

// Use a for-in loop to print every city in the cities array
for city in cities {
    print(city)
}

// Use a for-in loop to print only the cities that have more than 6 characters
// Hint: use city.count inside an if statement

for city in cities {
    if city.count > 6 {
        print(city)
    }
}

let temperatures = [72.1, 68.4, 85.0, 91.3, 77.6, 63.2]


// Use forEach to print every temperature in the array

temperatures.forEach {
    temp in print(temp)
}

// Use forEach with $0 shorthand to print each temperature multiplied by 2
temperatures.forEach { temp in
    print(temperatures + [Double(temp)])
}


// Use forEach to print only temperatures above 75.0

temperatures.forEach { temp in
    if temp > 75.0 {
        print(temp)
    }
}

let players = ["Maya", "Jordan", "Sam", "Taylor", "Alex"]
// Use enumerated() to print each player with their position number
// Example output: "Player 1: Maya"
// Note: add 1 to the index so numbering starts at 1, not 0

for (index, player) in players.enumerated() {
        print("Player \(index + 1): \(player)")
}



// Use enumerated() to print only players at even indexes (0, 2, 4...)
// Hint: use the % operator to check if the index is even
for(index, player) in players.enumerated() {
    if index % 2 == 0 {
        print(player)
    }
}

// Use enumerated() to print the index and value of every player
// whose name is shorter than 5 characters
for(index, player) in players.enumerated() {
    if player.count < 5 {
        print("Index: \(index), Player: \(player)")
    }
    /*for (index, player) in players.enumerated() {
     if player.count < 5 {
     print(player)
     }
    }
    */
}


// MIXED PRACTICE
let grades: [Double] = [78.5, 92.0, 55.3, 88.8, 73.1, 96.4, 61.0, 84.2]
let subjects = ["Math", "Science", "History", "English", "Art"]
// Print every subject in the subjects array


// Print each subject with its position, starting at 1
for subject in subjects{
    print(subjects)
}

// Example: "1. Math"
for (index, subject) in subjects.enumerated() {
    print("\(index + 1), \(subject)")
}

// Print each grade in the grades array
grades.forEach{grade
    in print(grade)
}

// Print only grades above 80.0
grades.forEach {grade in
    if grade > 80.0 {
        print(grade)
    }
}

// Print the index and value of any grade below 70.0

for (index, grade) in grades.enumerated() {
    if grade > 70.0 {
        print(grade)
    }
}

